# CCNA project "pkt" - MUET college campus topology
 networking project , DHCP , NAT static and dynamic, vlan and intervlan routing, etherchannel, rstp ,portfast,bpduguard, wireless and ip basedIOT
 just download the project and ready to go.
 check the connection " ping from telecom to cs(20.20.20.0 /24),ICPC(10.10.10.0 /24),SW(40.40.40.0 /24),CL(50.50.50.0 /24)
 access the SMIT webpage "www.SMIT.com"
 access the IT webpage "www.it.com"
 access the MUET webpage "www.muet.com"
 
 
